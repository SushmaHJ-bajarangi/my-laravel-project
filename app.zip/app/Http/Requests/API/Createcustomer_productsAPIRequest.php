<?php

namespace App\Http\Requests\API;

use App\Models\customer_products;
use InfyOm\Generator\Request\APIRequest;

class Createcustomer_productsAPIRequest extends APIRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return customer_products::$rules;
    }
}
